<div class="box box-solid" style="background: url('https://i.imgur.com/CCbvXuk.png') center center;">
    <div class="box-body">     
        <div class="card panel-body text-center">
            <span class="logo-lg wow bounceInDown" style="visibility: visible; animation-name: bounceInDown;">
            <font size="7" color="white" class="wow flash" style="text-transform: uppercase;text-shadow: 0px 0px 0px red, 0px 0px 0.5em red, 0px 0px 0.4em red;font-weight: bold">VIP LIKE GIÁ RẺ TẠI VTASYSTEM</font></span></br>
            <font size="4" color="white"class="wow shake" style="text-transform: uppercase;text-shadow: 0px 0px 0px blue, 0px 0px 0.5em blue, 0px 0px 0.4em blue;font-weight: bold">UY TÍN - CHẤT LƯỢNG - HIỆU QUẢ</font> </span></br></br>
            <a class="btn btn-info btn-lg wow bounceInDown" style="border-radius: 30px" href="index.php?vip=Login">Đăng Nhập Ngay</a>
            <a class="btn btn-success btn-lg wow bounceInLeft" style="border-radius: 30px" href="index.php?vip=Register">Đăng Ký Ngay</a>
            </p></pthis></p>
        </div>
    </div>
        </div>

<div class="row" style="margin-top:10px">
        <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 wow rotateIn">
            <div class="info-box panel-body text-center" style="background: #fff; border-radius:5px;">
                <div class="et_pb_main_blurb_image"><img style="width:100px" src="src/1.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>
                <div class="et_pb_blurb_container">
                    <h4>Công nghệ mới</h4>

                    <p>Mọi thứ đều được tự động hóa, ổn định, tối ưu hiệu suất với bộ mã nguồn độc quyền cùng với hệ thống máy chủ tốt nhất.</p>

                </div>
            </div>
        </div>
        <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 wow rotateIn">

            <div class="info-box panel-body text-center" style="background: #fff; border-radius:5px;">
                <div class="et_pb_main_blurb_image"><img style="width:100px" src="src/4.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>
                <div class="et_pb_blurb_container">
                    <h4>UI Chuyên Nghiệp</h4>

                    <p>Panel quản lí chuyên nghiệp dành riêng cho Đại lí, Cộng tác viên và các thành viên. Duy nhất có tại VTASYSTEM</p>

                </div>
            </div>
        </div>
        <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 wow rotateIn">

            <div class="info-box panel-body text-center" style="background: #fff; border-radius:5px;">
                <div class="et_pb_main_blurb_image"><img style="width:100px" src="src/2.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>
                <div class="et_pb_blurb_container">
                    <h4>Chi phí thấp</h4>

                    <p> Giá cả hợp lí, ưu đãi lớn dành cho Đại Lí & CTV. Có nhiều gói dịch vụ đáp ứng mọi nhu cầu của người dùng.</p>

                </div>
            </div>
        </div>
        <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12 wow rotateIn">
            <div class="info-box panel-body text-center" style="background: #fff; border-radius:5px;">
                <div class="et_pb_main_blurb_image"><img style="width:100px" src="src/3.png" alt="" class="et-waypoint et_pb_animation_off et-animated"></div>
                <div class="et_pb_blurb_container">
                    <h4>Bảo Mật & Hiệu quả</h4>

                    <p>Bạn không phải sử dụng Facebook cá nhân, chỉ cần tạo 1 tài khoản trên hệ thống và đăng kí chọn mua dịch vụ.</p>

                </div>
            </div>
        </div>
                </div>

        <div id="vtasystemnoti" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><center><strong>Thông Báo Mới</strong></center></h4>
            </div>
            <div class="modal-body">
                        <span class="h4">
                            <?php $xinchao = $getsetting['thongbao']; 
                             echo $xinchao; ?>
                        </span>
            </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-dismiss="modal">Đóng</button>
                    </div>
                </div>

            </div>
        </div>