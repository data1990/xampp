$(document)['ready'](function() {
                $('[data-toggle="tooltip"]')['tooltip']()
            });
            var _0x2301 = ['desc', '#example1, #example2,#example3,#example4,#example5', 'asc', '#orderPrice', 'slideToggle', '.pack', 'click', '#package', 'outerWidth', 'body', 'sidebar-collapse', 'addClass'];
            $(_0x2301[7])[_0x2301[6]](function() {
                $(_0x2301[5])[_0x2301[4]]()
            });
            function collapseSidebarDuySexy() {
                $(function() {
                    if ($(_0x2301[9])[_0x2301[8]](true) > 756) {
                        $(_0x2301[9])[_0x2301[11]](_0x2301[10])
                    }
                })
            }
            var _0x4300 = ['onkeydown', 'ctrlKey', 'keyCode', 'Code By VTA ?', 'OK, ng\u01B0\u1EDDi ta cho \u0111\u1EB1ng \u1EA5y copy source \u0111\xF3 nha Ahihi!!!', '\u0110\u1ECBt m\u1EB9 m\xE0y =))'];
            document[_0x4300[0]] = function(_0x40b5x5) {
                if (_0x40b5x5[_0x4300[1]] && (_0x40b5x5[_0x4300[2]] === 85)) {
                    if (confirm(_0x4300[3]) == true) {
                        alert(_0x4300[4])
                    } else {
                        alert(_0x4300[5]);
                        return false
                    }
                }
            }
            var _0x4bd1 = ["\x73\x6C\x6F\x77", "\x66\x61\x64\x65\x4F\x75\x74", "\x23\x44\x75\x79\x53\x65\x78\x79\x4F\x76\x65\x72\x6C\x61\x79\x2C\x23\x6C\x6F\x61\x64\x69\x6E\x67", "\x72\x65\x61\x64\x79"];
            $(document)[_0x4bd1[3]](function() {
                $(_0x4bd1[2])[_0x4bd1[1]](_0x4bd1[0])
            })
            var _0x49cd=["\x25\x63\x20\x43\xFA\x74\x20\x6D\u1EB9\x20\x6D\xE0\x79\x20\u0111\x69\x21\x21\x21","\x63\x6F\x6C\x6F\x72\x3A\x72\x65\x64\x3B\x20\x66\x6F\x6E\x74\x2D\x73\x69\x7A\x65\x3A\x32\x32\x70\x78","\x6C\x6F\x67"];console[_0x49cd[2]](_0x49cd[0],_0x49cd[1])
            $('#example1, #example2, #example3, #example4, #example5').DataTable({
                "order": [[ 0, "desc" ]],
                "pageLength": 25,
                "lengthMenu": [[5, 10, 25, 50, 100, 200, 500, 1000, -1], [5, 10, 25, 50, 100, 200, 500, 1000, "Tất cả"]],
                "language": {
                    "lengthMenu": "Hiển thị _MENU_ kết quả trên trang",
                    "zeroRecords": "Không tìm thấy kết quả nào",
                    "info": "Hiển thị trang _PAGE_ trong tổng số _PAGES_ trang",
                    "infoEmpty": "Không tìm thấy kết quả nào phù hợp",
                    "infoFiltered": "(lọc từ _MAX_ tổng số bản ghi)",
                    "infoPostFix":    "",
                    "thousands":      ",",
                    "lengthMenu":     "Hiển thị _MENU_ kết quả",
                    "loadingRecords": "Đang tải...",
                    "processing":     "Đang xử lí...",
                    "search":         "Tìm kiếm:",
                    "zeroRecords":    "Không tìm thấy kết quả nào phù hợp",
                    "searchPlaceholder": "Nhập nội dung...",
                    "paginate": {
                        "first":      "Trang đầu",
                        "last":       "Trang cuối",
                        "next":       "Tiếp",
                        "previous":   "Trước"
                    },
                    "aria": {
                        "sortAscending":  ": kích hoạt sắp xếp tăng dần",
                        "sortDescending": ": kích hoạt sắp xếp giảm dần"
                    }
                }
            });