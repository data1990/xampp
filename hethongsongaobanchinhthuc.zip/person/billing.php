<?php defined('COPYRIGHT') OR exit('hihi'); ?>
<div class="row">
    <div class="col-md-12 col-sm-12">
        <div class="col-md-6 wow fadeInDown">
            <div class="panel panel-success">
                <div class="panel-heading">
                    <b>Nạp Thẻ Trực Tiếp</b>
                </div>
                <div class="panel-body">
                    NẠP THẺ VUI LÒNG INBOX FACEBOOK.COM/NGUYENTHILANNHILOVEAHIHI HOẶC SMS 0919257664
                 <?php //require_once 'Card/doicard/index.php'; ?>
                </div>
            </div>
        </div>
    <div class="col-md-6 wow fadeInDown">
            <div class="panel panel-warning">
                <div class="panel-heading">
                    <b>Ngân hàng & Ví điện tử</b>
                </div>
                <div class="panel-body">

                    <table class="table table-bordered">
                        <thead>
                            <tr><td><center><b>VIETCOMBANK</b><br><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJcAAACXCAMAAAAvQTlLAAABIFBMVEX///8ARSIAbEIANAAAQRsAQx8APxcAdUYANwAAPBEAeEcAcUQAMAAeSin7/PwAPRTb49/O1NC/yMIAKgBXqkNjdWMAOgoARyAALQDq7uzx9fOvvbTl6Oalt6wdikY3mUUOgkebqJ5fr0IxXkQWQBtyuUFogW8okEZIoUQ8ZEoYVTOMnpIAYzUkTjFptEI2WkBNaVMAHgB1jH0AIgBDX0cAbTgAFwBaeWV/mIkACQBue3AAAABMX00YfVE0i19HkGBXnW90sn+IwIOCvXd3ull+wDp5oIvX68lYrSd+tpWVymtIgmao0os3gWBlsFkAeyyx0rqu06lAoC3h79vH4rePyFVHnF0PjSqkzpq22ZxtuSSavq5noIOJtp+Jw3AAWSGFtEI7AAAGoUlEQVR4nO2Ya3vTNhSApUhW7DbxtTW+NnVDnBjHTeo0xGPXbmu3wS5AGQyawv//FzuycytN2eVhMx/08jxEyLL95ujoSAEhgUAgEAgEAoFAIBAIBAKBQCAQCAQCgUAgEAjqRVXrNngf3by6ur6ez+fX10+fXn4Set7l67cH794Nh9PpdOfw8KDff/Xq1z/qdvNeP+792GkAu83mTuXVGQyeP3+r12ilvnhz3js+Pryp1RnsHR31jmoU+/lND7SODkBrd0MLvI57vZ9q03pRaR0NNsK10jr/2qvL6/E5eB0d7e01G5vJtbd3fNw7P99xa9LyHve4197eXr+xmVxVuI4bdXmpjyutwaCz0+Ram7N43n9S2zz+XM3iYDDof/nV1998c3Z29u233739ns9ib3pRWwn74ccqXINO5yfXW+1C3uWL388Hw6u6tBBahKvT6b+8Wa3U35uNGuvXs+eVVqffP7t55Wz4S407kfdrNYv9fv+3p5sXjMbwoi4pzrPni3AdHBxuzJv6ZDisc39EaK11+NW6LlwNh/VViZJnr5Zah9P5MqP0RqPO1cjxXvLk4lo7O8uK5T0ZNmor9ksuXy3CtQNi16XYxbDmrC85W2ntNEuxK4hWzVnP8V6utJrN6fzqgmvNP4Ej/uVvK63m7nQ45Ifq+sMFPF1r7e5yq+G8bqUS9XpaeS20GsO6F+OS+XQRrkqr5tq1xptPq3CVYr98KuGCqQSx1SyaddtsoF6ttOovqTe4+rKsEH93w9Z9010WOdUzfOPjWARpkb9XO9057D/Diw2tII/ju3ItnTgTf9E2LWfy6ONUYqNF7FtP0k3zRkE17tt2cMcDQhvb6bKtYKXYNiidzcJ/6EXpvb/8hkZbun+Xly9jbbxoFwq2t75/JrfSbf3/oZfewhJZnIvGDGsmUpc/qFTPK1sqihnEdNm7/r3FWfSV/SpafXCvzf8gVNXl77TF2E0v/pxbXwJL+KSa9YBJUuYG3SSBwZ4/bmPcjWEdPMqg1U4SSEPVj5NknEcwQI+hF7dzuNftJpGfjEZjQ49H8BGWXg/0tDua8dw1ojjJcHtUwFgj6ZphdzSamSsvb0xpcmuVzhTcqibPJJiNIYAKJKOaE4UBNjPRI1vCWNKcCKlj29Y0zT4JUdC1KVyncuYi19IyqjCqZJmsMaq1fPCScAaPUKCNIkvRYCgjpzoyZaWrwFj7vrHw8vZlLbt9wPAdzGZlK7YxSZEuSzRAhoVZe9RVsJahRwwCI2E5QgXBio0Z+dxAOTQzPqCVIxdyIcvaDEu0/GD7qkExzbpd+PvURf6E3MsyzHgATA1Xg+y88lJnhNIt5x6dStKI96uZhC1j4VXIbKy7bsEk2XX1GVVyHf45okps6oYZuegBdAVuEDOWgJd0zwigTbtBEORK6SWxwHV9MIa4pKYeBHpCIUtNDd4WBDNN21d18HJTWbL921pI3WfVKjQVzEbewmtMldRzPbMtEXAu8x7yQcaTZX4+oDJ/mq/QROVeLm+zLnSFrdKLYj6MYAIrySzyPC9O4auAF4WXoIhUXu0ZTNL2GhTBzCTglytYhrdXXl9QKTs9PR1hLBtrL4Jb6MNe6tqrrBNEAq/UsjkU3/bCGlbirVrIZRJ2IFMVSYJc5F4sQKcUYyLbtqJYm17Sdi/nA16y72YwqXyNcIW1V1x6lYm2Hch3WIdxFTbwog9ciJeS+vEM4DvY2kv+F/HSNck2dF0vyG2vdgyzdMdpn69pnN/H2DEqL1j6M568a/OFF8OT8hlq6cXTIvyAFx/YwrZhKJTyZ6Wkmsdk00sfMzbevnmr4IzBTRt7K6/QwTQOwzT/grvGGpv5YeCeQgGMwqjY11GX0RE0u1Sboa1esMoMM7elUQArXgt9PxpVec/G6sqLtj2jJd01k7qMOdRAKy8vg4QkRFagmvJvilnLMlFoSVQmxJ6YiFcAQgjFlr/20nghrLyg5rUsx8atArkJw6TVIgq+5SW1IQQaL5tbSR9alvWwstYnLQleYrYdSHqblL3BxCHkBPKpcAgsLPJZiNTCgmVhyxYcQNyHROZelsVPAOFDB7xkh1+2LZ5McOhRFGKNHQu8HGfEvU74IIXYcF96QibbI6ZCVurGYvcOw5DPpwqTWKRhlZOeGfrldTdK0yjUy605LeCPvr5FD0O+FIIoNPlOGvHLVcUMoryIdI9f4IPgbiOEtgv38SeZYRh9pPOoQCAQCAQCgUAgEAgEAoFAIBAIBAKBQCAQCAT/C38CFUjWNSDO0fcAAAAASUVORK5CYII="></center></td><td><b>- Số tài khoản: <font color="red">0021000407369</font></b><br> 
                            - Tên : <font color="red">NGUYEN DINH QUANG</font><br> 
                            - Chi nhánh: <font color="red">Chi Nhánh Hà Nội</font><br> 
                            - Nội Dung Chuyển Khoản: <font color="red"><b><?php echo isset($uname) ? $uname : 'Ten_tai_khoan_cua_ban'; ?> Nap Tien Mua Vip</b></font><br> 
                            </td></tr>
                        <tr><td><center><b>THẺ CÀO SIÊU RẺ</b><br><img src="person/logo/tcsr.png" height="35px" weight="32px"></center></td><td><b>- Tài khoản: <font color="red">nhianhlove</font></b><br>
                            - Tên : <font color="red">Vũ Tiến Anh</font><br>
                            - Nội Dung: "<b><?php echo isset($uname) ? $uname : 'Ten_tai_khoan_cua_ban'; ?> </b> Nap Tien Mua Vip"
                        </td></tr>
                        </tbody></table>

                </div>
            </div>
        </div>        </div>
        <div class="col-md-12 wow fadeInDown">
            <div class="panel panel-info">
                <div class="panel-heading">
                    <b>Thông tin thêm</b>
                </div>
                <div class="panel-body">
                    <span class="h4">
                        <p>
                        <b>- Nạp thẻ trực tiếp trên Website</b>, Số dư tài khoản của bạn <b>Tự động được cộng sau khi nạp thành công!</b>
                        </p>
                        <p>
                            <b>- Với các phương thức thanh toán khác</b>, số dư tài khoản của bạn sẽ được cộng <b>sau khi xác nhận thanh toán thành công với Admin</b>. Để nhanh chóng, bạn có thể liên hệ trực tiếp SĐT: <a href="tel:84919257664"><b>0919.257.664</b></a> sau khi chuyển tiền.</b>
                        </p>
                        <p>
                            <b>- KM cho Đại Lí & Cộng tác viên (CTV):</b><br />
                            <b style="color:red">+ Nạp tiền trên web: </b> + thêm <b>10%</b> cho Đại Lí & <b>5%</b> cho CTV<br />
                            <b style="color:red">+ Nạp tiền bằng ATM, Ví điện tử:</b> + thêm <b>15%</b> cho Đại Lí, <b>10%</b> cho CTV, <b>5%</b> cho Thành viên thường<br />
                            <b>+ Đại Lí</b> được giảm <b>10%</b>, <b>CTV</b> được giảm <b>5%</b> khi mua VIP!
                        </p>
                        <p>
                             <b>- Tất cả các chương trình khuyến mại nạp tiền khác sẽ tự động được áp dụng cho hình thức nạp tiền trên website. Với phương thức chuyển tiền qua ATM, Ví điện tử mình sẽ cộng tiền bao gồm cả KM sau khi xác nhận giao dịch thành công!</b>
                        </p>
        
                        <p><b>- Đại lí</b> vốn tối thiểu <b>>= 2 Triệu</b>, <b>CTV</b> vốn tối thiểu <b>>= 500K</b>
                        </p>                  
                        <p>- Facebook Admin : <strong style="color:red"><a href="https://www.facebook.com/1941732149410907" target="_blank">HETHONGSONGAO FANPAGE</a></strong> -  <strong style="color:red"><a href="https://www.facebook.com/1941732149410907" target="_blank">Dự phòng</a></strong></p>
                        <p>- Zalo Admin : <strong style="color:red">0919.257.664</strong></p>
                        <p>- Notice : <strong style="color:red">Tất cả vấn đề liên quan đến Nạp tiền và 1 số vấn đề liên quan đến bảo mật khác, FB và Zalo các bạn không liên lạc được thì SMS vào SĐT cho mình với nội dung là <code>Tên FB hoặc Link trang cá nhân của bạn, kèm nội dung của vấn đề</code> mình sẽ nhắn tin hoặc gọi lại nếu bạn yêu cầu nhé. Chứ mình ít khi nghe số lạ lắm, hihi :d</strong></p>
                        <p>* Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ tại <b>hethongsongao.com *</b> !</p>
                    </span>
                </div>
            </div>
        </div>
    </div>