<?php
// Api config
$config = array();
$config['PartnerID']    = 'vtasystem'; //do bên API cap
$config['PartnerKey'] 	= 'vtasystem@abc'; //do bên API cap
